<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service extends CI_Controller {

	function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('id_customer')) {
            redirect('/', 'refresh');
        }
    }

	public function index()
	{
		$this->load->model("Mservice");
        $data['layanan'] = $this->Mservice->tampil();

		$this->load->view('header');
		$this->load->view('service', $data);
		$this->load->view('footer');
	}

	public function pesan($id_layanan)
	{
		$this->load->model("Mservice");
		$data['detail_layanan'] = $this->Mservice->detail_layanan($id_layanan);

		$this->load->view('header');
		$this->load->view('service_order', $data);
		$this->load->view('footer');
	}

	public function proses_pesan() {
        $this->load->model("Mservice");

        // Data yang dikirim dari form
        $data = [
            'id_layanan' => $this->input->post('id_layanan'),
            'nama' => $this->input->post('nama'),
            'jumlah' => $this->input->post('jumlah'),
            'alamat' => $this->input->post('alamat'),
            'metode_pembayaran' => $this->input->post('metode_pembayaran'),
            'tanggal_pesan' => date('Y-m-d H:i:s')
        ];

        // Simpan ke database
        $this->db->insert('transaksi', $data);

        // Redirect ke halaman sukses atau kembali ke layanan
        redirect('order');
    }
}
